function confirmDelete() {
    if (confirm("Are you sure you want to delete?")) {
      // User clicked "OK", delete the item
      // Add your delete logic here
    } else {
      // User clicked "Cancel", do nothing
    }
  }

  function updateDepartment() {
    // Get the name entered by the user
    var name = document.getElementById("name").value;
  
    // Retrieve the department information from stored data
    var department = getDepartmentFromData(name);
  
    // Update the department text box with the retrieved information
    document.getElementById("department").value = department;
  }
  
  function getDepartmentFromData(name) {
    // Add your code here to retrieve the department information based on the user's name
    // This could involve querying a database, reading from a file, or accessing an API
    // For this example, we will simply return a hardcoded department value for demonstration purposes
    return "Sales";
  }