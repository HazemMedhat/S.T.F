# Student_Affairs_website
 Web application provides several functionalities like Add student, delete student, search student, update student information and other functionalities  
- the main pages built using HTML, CSS 
- Backend functions written using python (Django Framework) 
- Client-side validations done using JavaScript 
