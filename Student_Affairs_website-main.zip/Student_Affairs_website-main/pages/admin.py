from django.contrib import admin

# Register your models here.
from .models import StudForm
admin.site.register(StudForm)
