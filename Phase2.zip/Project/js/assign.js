// Retrieve data from local storage
const studentData = JSON.parse(localStorage.getItem('students'));

// Get the student ID from the URL parameter
const urlParams = new URLSearchParams(window.location.search);
const studentId = urlParams.get('id');

// Find the student with the matching ID
const student = studentData.find((x) => x.id === studentId);

// Populate the form with student data
document.getElementById('name').value = student.name;
document.getElementById('id').value = student.id;
document.getElementById('gpa').value = student.gpa;
document.getElementById('level').value = student.level;

// Update department options based on GPA
const gpaInput = document.getElementById('gpa');
const departmentSelect = document.getElementById('dep');

gpaInput.addEventListener('input', function () {
    const gpa = parseFloat(gpaInput.value);

    // Clear existing options
    departmentSelect.innerHTML = '';

    // Add options based on GPA
    if (gpa >= 3.0) {
        addDepartmentOption('Information System', 'IS');
        addDepartmentOption('Computer Science', 'CS');
        addDepartmentOption('Information Technology', 'IT');
        addDepartmentOption('Artificial Intelligence', 'AI');
        addDepartmentOption('Decision Support', 'DS');
    } else if (gpa >= 2.5 && gpa < 3.0) {
        addDepartmentOption('Information System', 'IS');
        addDepartmentOption('Information Technology', 'IT');
        addDepartmentOption('Decision Support', 'DS');
    } else {
        addDepartmentOption('Information Technology', 'IT');
        addDepartmentOption('Decision Support', 'DS');
    }
});

function addDepartmentOption(label, value) {
    const option = document.createElement('option');
    option.text = label;
    option.value = value || label;
    departmentSelect.appendChild(option);
}

function assignDepartment(event) {
    event.preventDefault(); // Prevent form submission

    var result = confirm("Are you sure you want to save changes?");

    if (result && student.level >= 3) {
        const department = departmentSelect.value;

        // Update the department attribute in the student object
        student.department = department;

        // Update the student data in the local storage
        const updatedStudentData = studentData.map((x) => {
            if (x.id === student.id) {
                return student;
            }
            return x;
        });
        if (student.gpa < 3.0 && departmentSelect.value === 'Computer Science') {
            alert("Assign Canceled, Student gpa is less than 3");
            return false;
        }
        else if (student.gpa < 3.0 && departmentSelect.value === 'Information System') {
            alert("Assign Canceled, Student gpa is less than 3");
            return false;
        }
        if (student.gpa < 2.5 && departmentSelect.value === 'Computer Science') {
            alert("Assign Canceled, Student gpa is less than 2.5");
            return false;
        }
        else if (student.gpa < 2.5 && departmentSelect.value === 'Information System') {
            alert("Assign Canceled, Student gpa is less than 2.5");
            return false;
        }
        else if (student.gpa < 2.5 && departmentSelect.value === 'Artificial Intelligence') {
            alert("Assign Canceled, Student gpa is less than 2.5");
            return false;
        }
        else {

            localStorage.setItem('students', JSON.stringify(updatedStudentData));

            // Display success message
            alert("Assign Department Done Successfully");
        }
    } else if (result && student.level < 3) {
        alert("Assign Canceled, Student Level is less than 3");
    } else {
        alert("Assign Canceled");
    }
    window.location.href = 'search.html';
}

