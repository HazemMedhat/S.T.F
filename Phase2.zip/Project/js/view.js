//change status (active,inactive)
function show_confirm() {  
  var r = confirm("Change Student Status?");
  if (r == true) {
    alert("Student status Changed Successfully!");
    return true;
  }
  else {
    alert("changing Status cancelled!");
    return false;
  }
}

//compare the text in the search with the data and display it
function myFunction() {
  var input, filter, table, tr, td, i, txtValue;
  input = document.getElementById("search")
  filter = input.value.toUpperCase();
  table = document.getElementById("myTable");
  tr = table.getElementsByTagName("tr");
  for (i = 1; i < tr.length; i++) {
    td = tr[i].getElementsByTagName("td")[0];
    if (td) {
      txtValue = td.textContent || td.innerText;
      if (txtValue.toUpperCase().indexOf(filter) > -1) {
        tr[i].style.display = "";
      }
      else {
        tr[i].style.display = "none";
      }
    }
  }
}

// Retrieve data from local storage
const students = JSON.parse(localStorage.getItem('students'));

// Get the table body element
const tableBody = document.getElementById('student-table-body');

// Iterate over the students array and create table rows dynamically
students.forEach(function (x) {
  // Create a new table row
  const row = document.createElement('tr');

  // Create table cells and populate them with student data
  const nameCell = document.createElement('td');
  nameCell.textContent = x.name;
  row.appendChild(nameCell);

  const idCell = document.createElement('td');
  idCell.textContent = x.id;
  row.appendChild(idCell);

  const departmentCell = document.createElement('td');
  departmentCell.textContent = x.department;
  row.appendChild(departmentCell);

  const levelCell = document.createElement('td');
  levelCell.textContent = x.level;
  row.appendChild(levelCell);

  const gpaCell = document.createElement('td');
  gpaCell.textContent = x.gpa;
  row.appendChild(gpaCell);

  const stateCell = document.createElement('td');
  const statusText = document.createElement('span');
  statusText.textContent = x.status;
  stateCell.appendChild(statusText);

  const changeStateButton = document.createElement('button');
  changeStateButton.className = 'apply';
  changeStateButton.title = 'Click here to change Student Status';
  changeStateButton.addEventListener('click', function () {
    var c = show_confirm();
    if (c) {
      const newStatus = statusText.textContent === 'active' ? 'inactive' : 'active';
      statusText.textContent = newStatus;
      x.status = newStatus;
      localStorage.setItem('students', JSON.stringify(students));
    }
  });

  const changeStateLink = document.createElement('a');
  changeStateLink.className = 'link';
  changeStateLink.href = '#';
  changeStateLink.textContent = 'Change';

  changeStateButton.appendChild(changeStateLink);
  stateCell.appendChild(changeStateButton);
  row.appendChild(stateCell);

  const editCell = document.createElement('td');
  const editLink = document.createElement('a');
  editLink.href = `edit.html?id=${x.id}`;
  const editIcon = document.createElement('i');
  editIcon.className = 'fas fa-edit';
  editLink.appendChild(editIcon);
  editLink.textContent = 'Edit';
  editCell.appendChild(editLink);
  row.appendChild(editCell);

  // Append the row to the table body
  tableBody.appendChild(row);
});
