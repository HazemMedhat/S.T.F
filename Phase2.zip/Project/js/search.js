//search on the student in the table
function myFunction() {
    var input, filter, table, tr, td, i, txtValue;
    input = document.getElementById("search")
    filter = input.value.toUpperCase();
    table = document.getElementById("myTable");
    tr = table.getElementsByTagName("tr");
    for (i = 1; i < tr.length; i++) {
        td = tr[i].getElementsByTagName("td")[0];
        if (td) {
            txtValue = td.textContent || td.innerText;
            if (txtValue.toUpperCase().indexOf(filter) > -1) {
                tr[i].style.display = "";
            }
            else {
                tr[i].style.display = "none";
            }
        }
    }
}

// Retrieve data from local storage
const students = JSON.parse(localStorage.getItem('students'));

// Get the table body element
const tableBody = document.getElementById('student-table-body');

// Iterate over the students array and create table rows dynamically
students.forEach(function (x) {
    if (x.status == "active") {
        // Create a new table row
        const row = document.createElement('tr');

        // Create table cells and populate them with student data
        const nameCell = document.createElement('td');
        nameCell.textContent = x.name;
        row.appendChild(nameCell);

        const idCell = document.createElement('td');
        idCell.textContent = x.id;
        row.appendChild(idCell);

        const gpaCell = document.createElement('td');
        gpaCell.textContent = x.gpa;
        row.appendChild(gpaCell);

        const departmentCell = document.createElement('td');
        departmentCell.textContent = x.department;
        row.appendChild(departmentCell);

        const levelCell = document.createElement('td');
        levelCell.textContent = x.level;
        row.appendChild(levelCell);

        const stateCell = document.createElement('td');
        stateCell.textContent = x.status;
        row.appendChild(stateCell);

        const assignCell = document.createElement('td');
        const assignLink = document.createElement('a');
        assignLink.href = `assign.html?id=${x.id}`; // Update the href with the student's ID
        assignLink.innerHTML = '<i class="fas fa-edit"></i> Assign Department';
        assignCell.appendChild(assignLink);
        row.appendChild(assignCell);
        // Append the row to the table body
        tableBody.appendChild(row);
    }
});
