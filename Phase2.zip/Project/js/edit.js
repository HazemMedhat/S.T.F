
//js form validation
var form = document.getElementById("form2");

form.addEventListener("submit", (e) => {

    var isValid = true;
    //name validation
    var studentname = document.getElementById("name").value;

    if (studentname === "") {
        document.getElementById("nameerror").innerHTML = " *Student Name is Required";
        document.getElementById("name").focus();
        isValid = false;
    }
    else if (isNaN(studentname) === false) {
        document.getElementById("nameerror").innerHTML = " *Student Name Can not be a number";
        document.getElementById("name").focus();
        isValid = false;
    }
    else {
        document.getElementById("nameerror").innerHTML = "";
        isValid = (isValid) ? true : false;
    }
    //id validation
    var studentid = document.getElementById("id").value;

    if (studentid.toString().length == 0) {
        document.getElementById("iderror").innerHTML = " *Student ID is Required";
        document.getElementById("id").focus();
        isValid = false;
    }
    else if (studentid.toString().length < 8 && studentid.toString().length != 0) {
        document.getElementById("iderror").innerHTML = " *Student ID Must contians 8 number";
        document.getElementById("id").focus();
        isValid = false;
    }
    else {
        document.getElementById("iderror").innerHTML = "";
        isValid = (isValid) ? true : false;
    }
    //birth date validation
    var studentBD = document.getElementById("date").value;

    if (studentBD === "") {
        document.getElementById("dateerror").innerHTML = " *Student Birth date is Required";
        document.getElementById("date").focus();
        isValid = false;
    }
    else {
        document.getElementById("dateerror").innerHTML = "";
        isValid = (isValid) ? true : false;
    }
    //gpa validation
    var studentgpa = document.getElementById("gpa").value;


    if (studentgpa === "") {
        document.getElementById("gpaerror").innerHTML = " *Student Gpa is Required";
        document.getElementById("gpa").focus();
        isValid = false;
    }
    else {
        document.getElementById("gpaerror").innerHTML = "";
        isValid = (isValid) ? true : false;
    }
    //Gender validation
    var studentgender = document.getElementById("gender").value;

    if (studentgender === "") {
        document.getElementById("gendererror").innerHTML = " *Student Gender is Required";
        document.getElementById("gender").focus();
        isValid = false;
    }
    else if (isNaN(studentgender) === false) {
        document.getElementById("gendererror").innerHTML = " *Student Gender Can not be a number";
        document.getElementById("gender").focus();
        isValid = false;
    }
    else if (studentgender !== "Female" && studentgender !== "female" && studentgender !== "Male" && studentgender !== "male") {
        document.getElementById("gendererror").innerHTML = " *Write Correct Gender";
        document.getElementById("gender").focus();
        isValid = false;
    }
    else {
        document.getElementById("gendererror").innerHTML = "";
        isValid = (isValid) ? true : false;
    }
    //level validation
    var studentlev = document.getElementById("level").value;
    if (studentlev === "") {
        document.getElementById("levelerror").innerHTML = " *Student Level is Required";
        document.getElementById("level").focus();
        isValid = false;
    }
    else if (studentlev !== "1" && studentlev !== "2" && studentlev !== "3" && studentlev !== "4") {
        document.getElementById("levelerror").innerHTML = " *write correct level 1 or 2 or 3 or 4";
        document.getElementById("level").focus();
        isValid = false;
    }
    else {
        document.getElementById("levelerror").innerHTML = "";
        isValid = (isValid) ? true : false;
    }
    //status validation
    var status = document.getElementById("stats").value;

    if (status === "") {
        document.getElementById("statuserror").innerHTML = " *Student State is Required";
        document.getElementById("stats").focus();
        isValid = false;
    }
    else if (status !== 'active' && status !== 'Active' && status !== 'inactive' && status !== 'Inactive') {
        document.getElementById("statuserror").innerHTML = " *Student State active or inactive";
        document.getElementById("stats").focus();
        isValid = false;
    }
    else {
        document.getElementById("statuserror").innerHTML = "";
        isValid = (isValid) ? true : false;
    }
    //email validation
    var studentemail = document.getElementById("em").value;


    let at = studentemail.indexOf("@");
    let dot = studentemail.indexOf(".");

    if (studentemail === "") {
        document.getElementById("emailerror").innerHTML = " *Student Email is Required";
        document.getElementById("em").focus();
        isValid = false;
    }
    else if (at == -1 || dot == -1) {
        document.getElementById("emailerror").innerHTML = " *Invalid Email";
        document.getElementById("em").focus();
        isValid = false;
    }
    else {
        document.getElementById("emailerror").innerHTML = "";
        isValid = (isValid) ? true : false;
    }
    //mobile number validation
    var studentphone = document.getElementById("mnum").value;

    let x = studentphone.indexOf("011");
    let y = studentphone.indexOf("010");
    let z = studentphone.indexOf("012");
    let w = studentphone.indexOf("015");
    if (studentphone === "") {
        document.getElementById("phoneerror").innerHTML = " *Student Mobile Number is Required";
        document.getElementById("mnum"), focus();
        isValid = false;
    }
    else if (studentphone.length < 11) {
        document.getElementById("phoneerror").innerHTML = " *Invalid Mobile Number";
        document.getElementById("mnum"), focus();
        isValid = false;
    }
    else if (x != 0 && y != 0 && z != 0 && w != 0) {
        document.getElementById("phoneerror").innerHTML = " *Invalid Mobile Number";
        document.getElementById("mnum"), focus();
        isValid = false;
    }
    else {
        document.getElementById("phoneerror").innerHTML = "";
        isValid = (isValid) ? true : false;
    }
    //if all info is validated
    if (isValid == false) {
        e.preventDefault();
    }
})




// Retrieve data from local storage
const studentData = JSON.parse(localStorage.getItem('students'));

// Get the student ID from the URL parameter
const urlParams = new URLSearchParams(window.location.search);
const studentId = urlParams.get('id');

// Find the student with the matching ID
const student = studentData.find((x) => x.id === studentId);

// Populate the form with student data
document.getElementById('name').value = student.name;
document.getElementById('id').value = student.id;
document.getElementById('date').value = student.birthdate;
document.getElementById('gpa').value = student.gpa;
document.getElementById('gender').value = student.gender;
document.getElementById('level').value = student.level;
document.getElementById('stats').value = student.status;
document.getElementById('dep').value = student.department;
document.getElementById('em').value = student.email;
document.getElementById('mnum').value = student.phone;

// Function to handle form submission (Update button)
function ConfirmEdit() {
    var c = Check();
    if (c) {
        // Retrieve the updated form values
        const updatedData = {
            name: document.getElementById('name').value,
            id: document.getElementById('id').value,
            birthdate: document.getElementById('date').value,
            gpa: document.getElementById('gpa').value,
            gender: document.getElementById('gender').value,
            level: document.getElementById('level').value,
            status: document.getElementById('stats').value,
            department: document.getElementById('dep').value,
            email: document.getElementById('em').value,
            phone: document.getElementById('mnum').value,
        };

        // Update the student data in local storage
        const updatedStudentData = studentData.map((x) => {
            if (x.id === updatedData.id) {
                return updatedData;
            } else {
                return x;
            }
        });
        localStorage.setItem('students', JSON.stringify(updatedStudentData));

        // Perform an AJAX request to update the server-side data
        const xhr = new XMLHttpRequest();
        xhr.open('POST', '/update-student', true);
        xhr.setRequestHeader('Content-Type', 'application/json');
        xhr.onreadystatechange = function () {
            if (xhr.readyState === XMLHttpRequest.DONE && xhr.status === 200) {
                // Request successful, handle the response
                const response = JSON.parse(xhr.responseText);
               
                window.location.href = 'view.html';
            }
        };
        xhr.send(JSON.stringify(updatedData));

        window.location.href = 'view.html';
        // Return false to prevent the form from submitting normally
        return false;
    }
}

// Function to handle delete confirmation (Delete button)
function confirmaDelete() {
    var result = confirm("To confirm deleting press ok");
    if (result) {
        const studentId = document.getElementById('id').value;
        deleteStudent(studentId);
        alert("Student Deleted Successfully");
        window.location.href = 'view.html';
    }
    else {
        alert("Deletion Canceled");
    }

    return false;
}


// Function to delete a student from local storage
function deleteStudent(studentId) {
    // Retrieve the student data from local storage
    const students = JSON.parse(localStorage.getItem('students'));

    // Find the index of the student with the specified ID
    const studentIndex = students.findIndex(student => student.id === studentId);

    // If the student exists, remove it from the array
    if (studentIndex !== -1) {
        students.splice(studentIndex, 1);

        // Update the student data in local storage
        localStorage.setItem('students', JSON.stringify(students));
    }
}



function Check() {
    var result = confirm("Are you sure you want to update student data ?");

    if (result) {
        alert("Updated succefully");
        return true;
    }
    else {
        alert("Updated Canceled");
        return false;
    }
}
